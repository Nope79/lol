// Juan Manuel López Almanza / S22120235
// César Isaac Quintino Aguilera / S22120174

const config = require('../dbconfig');
const util = require('util');
const mysql = require('mysql');

const db = makeDb(config);

function makeDb(cfg) {
  const connection = mysql.createConnection(cfg);
  return {
    query(sql, args) {
      return util.promisify(connection.query).call(connection, sql, args);
    },
    close() {
      return util.promisify(connection.end).call(connection);
    }
  };
}

// Prueba funcional
async function getDocentes() {
  try {
    return await db.query('SELECT * FROM docentes WHERE idDocente = 1;');
  } catch (error) {
    console.error(error);
  }
}


async function verifyDocentes() {
  try {
    return await db.query('SELECT * FROM docentes');
  } catch (err) {
    console.error(err);
    throw err;
  }
}

async function getCarreras() {
  try {
    return await db.query('SELECT * FROM carreras');
  } catch (err) {
    console.error(err);
    throw err;
  }
}

async function getMaterias() {
  try {
    return await db.query('SELECT * FROM materias');
  } catch (err) {
    console.error(err);
    throw err;
  }
}

async function getSoftware() {
  try {
    return await db.query('SELECT * FROM software');
  } catch (err) {
    console.error(err);
    throw err;
  }
}

async function getMateriasSistemasComp() {
  try {
    return await db.query('SELECT * FROM materias WHERE idcarrera = 1');
  } catch (err) {
    console.error(err);
    throw err;
  }
}

async function getMateriasSistemasAuto() {
  try {
    return await db.query('SELECT * FROM materias WHERE idcarrera = 2');
  } catch (err) {
    console.error(err);
    throw err;
  }
}

async function getMateriasGest() {
  try {
    return await db.query('SELECT * FROM materias WHERE idcarrera = 3');
  } catch (err) {
    console.error(err);
    throw err;
  }
}

async function getMateriasElec() {
  try {
    return await db.query('SELECT * FROM materias WHERE idcarrera = 4');
  } catch (err) {
    console.error(err);
    throw err;
  }
}

async function getMateriasGastro() {
  try {
    return await db.query('SELECT * FROM materias WHERE idcarrera = 5');
  } catch (err) {
    console.error(err);
    throw err;
  }
}

async function getMateriasAmb() {
  try {
    return await db.query('SELECT * FROM materias WHERE idcarrera = 6');
  } catch (err) {
    console.error(err);
    throw err;
  }
}

async function getMateriasIndus() {
  try {
    return await db.query('SELECT * FROM materias WHERE idcarrera = 7');
  } catch (err) {
    console.error(err);
    throw err;
  }
}

async function getMateriasConduc() {
  try {
    return await db.query('SELECT * FROM materias WHERE idcarrera = 8');
  } catch (err) {
    console.error(err);
    throw err;
  }
}

module.exports = {
  getDocentes,
  verifyDocentes,
  getCarreras,
  getMaterias,
  getSoftware,
  getMateriasSistemasComp,
  getMateriasSistemasAuto,
  getMateriasGest,
  getMateriasElec,
  getMateriasGastro,
  getMateriasAmb,
  getMateriasIndus,
  getMateriasConduc,
};
