// Juan Manuel López Almanza / S22120235
// César Isaac Quintino Aguilera / S22120174

const config = {
    host     : 'localhost',
    port     : '3306',
    user     : 'root',
    password : '1234',
    database : 'cc',
}
module.exports = config;