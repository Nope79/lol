// Juan Manuel López Almanza / S22120235
// César Isaac Quintino Aguilera / S22120174

const regdocDao = require('./DAOS/regdocDao');
const helmet = require("helmet");
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const router = express.Router();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors());
app.use(helmet());
app.use('/api', router);

// Ruta de bienvenida eg: http://localhost:8090
app.get("/", (_request, response) => {
    response.send("Bienvenido a la API creada en TAPzzzzzzzzzzzzz");
});

// http://localhost:8090/api/docentes
router.route('/docentes').get((_request, response) => {
    console.log(":D");
    regdocDao.getDocentes().then(resultset => {
        response.json(resultset);
    }).catch(error => {
        response.status(500).json({ message: "Error interno del servidor", error });
    });
});

// http://localhost:8090/api/entrar
router.route('/entrar').get((req, res) => {
    console.log("Entrando");
    regdocDao.verifyDocentes().then(resultset => {
        res.json(resultset);
    }).catch(error => {
        res.status(500).json({ message: "Error interno del servidor", error });
    });
});

// http://localhost:8090/api/carreras
router.route('/carreras').get((req, res) => {
    console.log("carreras");
    regdocDao.getCarreras().then(resultset => {
        res.json(resultset);
    }).catch(error => {
        res.status(500).json({ message: "Error interno del servidor", error });
    });
});

// http://localhost:8090/api/materias
router.route('/materias').get((req, res) => {
    console.log("materias");
    regdocDao.getMaterias().then(resultset => {
        res.json(resultset);
    }).catch(error => {
        res.status(500).json({ message: "Error interno del servidor", error });
    });
});

// http://localhost:8090/api/software
router.route('/software').get((req, res) => {
    console.log("software");
    regdocDao.getSoftware().then(resultset => {
        res.json(resultset);
    }).catch(error => {
        res.status(500).json({ message: "Error interno del servidor", error });
    });
});

// http://localhost:8090/api/materias/1
router.route('/materias/1').get((req, res) => {
    console.log("Sistemas");
    regdocDao.getMateriasSistemasComp().then(resultset => {
        res.json(resultset);
    }).catch(error => {
        res.status(500).json({ message: "Error interno del servidor", error });
    });
});

// http://localhost:8090/api/materias/2
router.route('/materias/2').get((req, res) => {
    console.log("Automotriz");
    regdocDao.getMateriasSistemasAuto().then(resultset => {
        res.json(resultset);
    }).catch(error => {
        res.status(500).json({ message: "Error interno del servidor", error });
    });
});

// http://localhost:8090/api/materias/3
router.route('/materias/3').get((req, res) => {
    console.log("Gestion");
    regdocDao.getMateriasGest().then(resultset => {
        res.json(resultset);
    }).catch(error => {
        res.status(500).json({ message: "Error interno del servidor", error });
    });
});

// http://localhost:8090/api/materias/4
router.route('/materias/4').get((req, res) => {
    console.log("Elect");
    regdocDao.getMateriasElec().then(resultset => {
        res.json(resultset);
    }).catch(error => {
        res.status(500).json({ message: "Error interno del servidor", error });
    });
});

// http://localhost:8090/api/materias/5
router.route('/materias/5').get((req, res) => {
    console.log("Gastro");
    regdocDao.getMateriasGastro().then(resultset => {
        res.json(resultset);
    }).catch(error => {
        res.status(500).json({ message: "Error interno del servidor", error });
    });
});

// http://localhost:8090/api/materias/6
router.route('/materias/6').get((req, res) => {
    console.log("Amb");
    regdocDao.getMateriasAmb().then(resultset => {
        res.json(resultset);
    }).catch(error => {
        res.status(500).json({ message: "Error interno del servidor", error });
    });
});

// http://localhost:8090/api/materias/7
router.route('/materias/7').get((req, res) => {
    console.log("Industrial");
    regdocDao.getMateriasIndus().then(resultset => {
        res.json(resultset);
    }).catch(error => {
        res.status(500).json({ message: "Error interno del servidor", error });
    });
});

// http://localhost:8090/api/materias/8
router.route('/materias/8').get((req, res) => {
    console.log("Conduc");
    regdocDao.getMateriasConduc().then(resultset => {
        res.json(resultset);
    }).catch(error => {
        res.status(500).json({ message: "Error interno del servidor", error });
    });
});

const port = process.env.PORT || 8090;
app.listen(port);
console.log('API REST Iniciada en el puerto : ' + port); 
