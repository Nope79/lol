import React, { useState, useEffect } from 'react';
import { Encabezado } from "../components/Encabezado";
import ToggleButton from "@mui/material/ToggleButton";
import ToggleButtonGroup from "@mui/material/ToggleButtonGroup";
import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";
import Slider from "@mui/material/Slider";
import Input from "@mui/material/Input";
import Stack from "@mui/material/Stack";
import Button from "@mui/material/Button";

export function Registro(props) {
  const [carreras, setCarreras] = useState([]);
  const [materias, setMaterias] = useState([]);
  const [carreraSeleccionada, setCarreraSeleccionada] = useState(null);
  const [materiasSeleccionadas, setMateriasSeleccionadas] = useState([]);
  const [atActual, setAtActual] = useState("at1");
  const [cantAlumnos, setCantAlumnos] = useState(0);
  const [software, setSoftware] = useState([]);
  const [softwareSeleccionado, setSoftwareSeleccionado] = useState([]);

  useEffect(() => {
    fetch('http://localhost:8090/api/carreras')
      .then(response => response.json())
      .then(data => {
        setCarreras(data.map((carrera, index) => ({ ...carrera, id: index })));
      })
      .catch(error => {
        console.error("Error fetching carreras:", error);
      });
  }, []);

  useEffect(() => {
    fetch('http://localhost:8090/api/software')
      .then(response => response.json())
      .then(data => {
        setSoftware(data.map((soft, index) => ({ ...soft, id: index })));
      })
      .catch(error => {
        console.error("Error fetching software:", error);
      });
  }, []);

  const onAtSeleccionada = (event, aulaSeleccionada) => {
    setAtActual(aulaSeleccionada);
  };

  const onChangeCantAlumnSlider = (event, nuevaCantidad) => {
    setCantAlumnos(nuevaCantidad);
  };

  const onChangeCantAlumnInput = (event) => {
    setCantAlumnos(event.target.value);
  };

  const onChangeCarrera = async (event, carreraSeleccionada) => {
    setCarreraSeleccionada(carreraSeleccionada);
    setMateriasSeleccionadas([]); // Limpiar materias seleccionadas
    if (carreraSeleccionada) {
      try {
        const response = await fetch(`http://localhost:8090/api/materias/${carreraSeleccionada.clave}`);
        const materias = await response.json();
        setMaterias(materias.map((materia, index) => ({ ...materia, id: index })));
      } catch (error) {
        console.error("Error fetching materias:", error);
      }
    } else {
      setMaterias([]);
    }
  };

  const onBotonGuardarClick = () => {
    props.setActualizarDocente(null);
  };

  return (
    <div className="Acceso, Registro">
      <Encabezado />
      <br />
      <h4>Docente: {props.docente.nombre}</h4>
      <br /><br />
      <p>Aula Tecnológica:</p>
      <ToggleButtonGroup
        color="primary"
        exclusive
        value={atActual}
        onChange={onAtSeleccionada}
        aria-label="AT utilizada"
      >
        <ToggleButton value="at1">AT1</ToggleButton>
        <ToggleButton value="at2">AT2</ToggleButton>
        <ToggleButton value="at3">AT3</ToggleButton>
        <ToggleButton value="at4">AT4</ToggleButton>
        <ToggleButton value="at5">AT5</ToggleButton>
      </ToggleButtonGroup>
      <br /><br /><br />

      <p>Carrera:</p>
      <Autocomplete
        options={carreras}
        getOptionLabel={(option) => option.carrera || ""}
        disablePortal
        onChange={onChangeCarrera}
        isOptionEqualToValue={(option, value) => option.id === value.id}
        renderInput={(params) => (
          <TextField
            {...params}
            label="Ingresar carrera"
            InputProps={{
              ...params.InputProps,
              style: { color: "white" },
            }}
            InputLabelProps={{
              style: { color: "white" },
            }}
          />
        )}
      />

      <br /><br />
      <p>Materia:</p>
      <Autocomplete
        disablePortal
        options={materias}
        getOptionLabel={(option) => option.nombre || ""}
        value={materiasSeleccionadas}
        onChange={(event, newValue) => {
          setMateriasSeleccionadas(newValue);
        }}
        isOptionEqualToValue={(option, value) => option.id === value.id}
        renderInput={(params) => (
          <TextField
            {...params}
            label="Selecciona una Materia"
            InputProps={{
              ...params.InputProps,
              style: { color: "white" },
            }}
            InputLabelProps={{
              style: { color: "white" },
            }}
          />
        )}
      />
      <br /><br />
      <p>Cantidad de alumnos:</p>
      <Stack direction="row" spacing={2}>
        <Slider
          value={cantAlumnos}
          onChange={onChangeCantAlumnSlider}
          aria-labelledby="input-slider"
          max={45}
        />
        <Input
          value={cantAlumnos}
          size="small"
          onChange={onChangeCantAlumnInput}
          inputProps={{
            step: 1,
            min: 0,
            max: 45,
            type: "number",
            "aria-labelledby": "input-slider",
          }}
        />
      </Stack>
      <br /><br />

      <p>Software:</p>
      <Autocomplete
        multiple
        options={software}
        getOptionLabel={(option) => option.nombre || ""}
        value={softwareSeleccionado}
        onChange={(event, newValue) => {
          setSoftwareSeleccionado(newValue);
        }}
        isOptionEqualToValue={(option, value) => option.id === value.id}
        renderInput={(params) => (
          <TextField
            {...params}
            variant="standard"
            placeholder="Elige el(los) software utilizados."
            InputProps={{
              ...params.InputProps,
              style: { color: "white" },
            }}
            InputLabelProps={{
              style: { color: "white" },
            }}
          />
        )}
      />
      <br />
      <Button
        onClick={onBotonGuardarClick}
        variant="contained"
        placeholder="Guardar"
      >
        GUARDAR
      </Button>
    </div>
  );
}
