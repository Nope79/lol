// Juan Manuel López Almanza / S22120235
// César Isaac Quintino Aguilera / S22120174

import { Encabezado } from "../components/Encabezado";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import LoginIcon from "@mui/icons-material/Login";
import { useState } from "react";

export function Acceso(props) {
  const [claveDocente, setClaveDocente] = useState("");

  function onTxtClaveDocenteChange(event) {
    setClaveDocente(event.target.value);
  }

  async function onBotonEntrarClick(event) {
    try {
      console.log("Verificando la clave del docente en acceso:", claveDocente);

      const response = await fetch(`http://localhost:8090/api/entrar`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });

      const data = await response.json();
      console.log("Respuesta del servidor:", data);

      const docenteEncontrado = data.find(docente => docente.clave == claveDocente);

      if (docenteEncontrado) {
        console.log("Clave válida. Redireccionando...");
        props.setActualizarDocente(docenteEncontrado);
      } else {
        alert("Acceso denegado. Clave incorrecta.");
      }
    } catch (error) {
      console.error("Error al verificar la clave del docente:", error);
      alert("Hubo un error al verificar el acceso. Por favor, intenta nuevamente.");
    }
  }

  return (
    <div className="Acceso">
      <Encabezado />

      <div className="reg">
        <TextField
          InputProps={{
            style: { color: "white" },
          }}
          inputProps={{
            style: { color: "white" },
          }}
          className="tf1"
          variant="filled"
          placeholder="Clave de docente"
          onChange={onTxtClaveDocenteChange}
        />
      </div>

      <Button
        className="bt1"
        onClick={onBotonEntrarClick}
        variant="contained"
        startIcon={<LoginIcon />}
        placeholder="Registrarse"
      >
        Registrate
      </Button>
    </div>
  );
}
