// Juan Manuel López Almanza / S22120235
// César Isaac Quintino Aguilera / S22120174

import { StrictMode } from "react";
import { createRoot } from "react-dom/client";

import App from "./App";
const rootElement = document.getElementById("root");
const root = createRoot(rootElement);

root.render(
  <StrictMode>
    <App />
  </StrictMode>
);
