// Juan Manuel López Almanza / S22120235
// César Isaac Quintino Aguilera / S22120174

export function Encabezado() {
  return (
    <div className="Encabezado">
      <h1>Aulas Tecnológicas</h1>
      <h2>Registro</h2>
    </div>
  );
}
